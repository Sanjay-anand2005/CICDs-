import express from "express";
import {
  registerUser,
  loginUser,
  logoutUser,
  getUserDetails
} from "../controllers/authController.js";

import { isAuthenticatedUser } from "../middlewares/auth.js";

const router = express.Router();

// REGISTER
router.post("/register", registerUser);

// LOGIN
router.post("/login", loginUser);

// LOGOUT
router.get("/logout", logoutUser);

// GET USER DETAILS (protected)
router.get("/me", isAuthenticatedUser, getUserDetails);

export default router;
