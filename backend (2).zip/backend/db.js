import mysql from "mysql2";

const connection = mysql.createConnection({
  host: "host.docker.internal",  // ← CHANGE THIS
  user: "root",
  password: "root",
  database: "flipkart",
  port: 3306
});

connection.connect((err) => {
  if (err) {
    console.log("❌ DB Connection Failed:", err);
  } else {
    console.log("✅ MySQL Database Connected!");
  }
});

export default connection;
