import User from "../models/userModel.js";
import ErrorHandler from "../utils/errorHandler.js";
import asyncErrorHandler from "../middlewares/asyncErrorHandler.js";
import sendToken from "../utils/sendToken.js";
import bcrypt from "bcrypt";

// ⭐ REGISTER USER
export const registerUser = asyncErrorHandler(async (req, res, next) => {
  const { name, email, password, gender, role } = req.body;

  // check existing user
  let user = await User.findOne({ email });
  if (user) return next(new ErrorHandler("User already exists", 400));

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  user = await User.create({
    name,
    email,
    password: hashedPassword,
    gender,
    role: role || "user", // default role = user
  });

  // Create & send JWT cookie
  sendToken(user, 201, res);
});

// ⭐ LOGIN USER
export const loginUser = asyncErrorHandler(async (req, res, next) => {
  const { email, password } = req.body;

  // Check missing fields
  if (!email || !password)
    return next(new ErrorHandler("Please enter email & password", 400));

  // Find user
  const user = await User.findOne({ email }).select("+password");
  if (!user) return next(new ErrorHandler("Invalid email or password", 401));

  // Compare password
  const isPasswordMatch = await bcrypt.compare(password, user.password);
  if (!isPasswordMatch)
    return next(new ErrorHandler("Invalid email or password", 401));

  sendToken(user, 200, res);
});

// ⭐ LOGOUT USER
export const logoutUser = asyncErrorHandler(async (req, res, next) => {
  res.cookie("token", null, {
    expires: new Date(Date.now()),
    httpOnly: true,
  });

  res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
});

// ⭐ GET USER DETAILS
export const getUserDetails = asyncErrorHandler(async (req, res, next) => {
  const user = await User.findById(req.user.id);

  res.status(200).json({
    success: true,
    user,
  });
});
