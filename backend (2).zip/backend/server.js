import express from "express";
import dotenv from "dotenv";
import connection from "./db.js";  // MySQL connection file
import bcrypt from "bcrypt";       // ✔ Add bcrypt for password hashing

dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.get('/api/health', (req, res) => {
    res.status(200).json({
        status: "OK",
        message: "Backend running successfully!"
    });
});


// Default route
app.get("/", (req, res) => {
  res.send("✅ API is running...");
});

// --------------------------------------------------------------------
// GET ALL USERS
// --------------------------------------------------------------------
app.get("/users", (req, res) => {
  connection.query("SELECT * FROM users", (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// --------------------------------------------------------------------
// SIGNUP (REGISTER) API
// --------------------------------------------------------------------
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  // Validate fields
  if (!name || !email || !password) {
    return res.status(400).json({
      message: "Name, Email, and Password are required",
    });
  }

  try {
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert into MySQL
    connection.query(
      "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
      [name, email, hashedPassword],
      (err, results) => {
        if (err) {
          if (err.code === "ER_DUP_ENTRY") {
            return res.status(400).json({
              message: "❌ Email already exists",
            });
          }

          return res.status(500).json({
            error: err.message,
          });
        }

        return res.status(201).json({
          message: "🎉 User registered successfully!",
          userId: results.insertId,
        });
      }
    );
  } catch (error) {
    return res.status(500).json({ error: "Server error" });
  }
});

// --------------------------------------------------------------------
// START SERVER
// --------------------------------------------------------------------
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
